class UnAuthorized(Exception):
    status_code = 401